package com.example.snoee.myapplistview.interfaces;

public interface Communicator {

    public void onDialogMessage(String tag, String message);

}
