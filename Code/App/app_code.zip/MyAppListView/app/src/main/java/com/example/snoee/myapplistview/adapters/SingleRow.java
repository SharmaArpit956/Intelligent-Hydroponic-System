package com.example.snoee.myapplistview.adapters;

public class SingleRow {
     int image;
      String title;
     String description;

    public SingleRow(int image, String title, String description) {
        this.image = image;
        this.title = title;
        this.description = description;
    }
}
