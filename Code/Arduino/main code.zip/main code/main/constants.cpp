#include "constants.h"
// This is a small number so that it's easy to read the logs
const int kInferencesPerCycle = 1000;
