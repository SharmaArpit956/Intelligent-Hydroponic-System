# Adafruit TensorFlow Lite Library [![Build Status](https://travis-ci.com/adafruit/Adafruit_TFLite.svg?branch=master)](https://travis-ci.com/adafruit/Adafruit_TFLite)

This is the Adafruit TensorFlow Lite Helper Library

Adafruit invests time and resources providing this open source code, please support Adafruit and open-source hardware by purchasing products from Adafruit!

Written by Limor Fried for Adafruit Industries.  
Apache2 license to match TensorFlow, check license.txt for more information
All text above must be included in any redistribution

To install, use the Arduino Library Manager and search for "Adafruit Tensorflow Lite" and install the library.
